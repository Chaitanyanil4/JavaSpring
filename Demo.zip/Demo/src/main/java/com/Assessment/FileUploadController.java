package com.Assessment;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;


import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@RestController
public class FileUploadController {
    private MultipartFile file;
    private List<String> attributeRows = new ArrayList<>();

    @GetMapping("/")
    public ModelAndView index() {
        return new ModelAndView("upload");
    }

    @PostMapping("/uploadFile")
    public ModelAndView uploadFile(@RequestParam("file") MultipartFile file,@RequestParam("attribute") String name, Model model) throws IOException {
        this.file = file;
        String originalFilename = file.getOriginalFilename();
        String type = originalFilename.substring(originalFilename.lastIndexOf(".") + 1).toLowerCase();
        String fileContent = new String(file.getBytes(), StandardCharsets.UTF_8);
        String name1=new String(name.getBytes(), StandardCharsets.UTF_8);
        String resultContent = ""; 
        if (type.equalsIgnoreCase("txt") || (type.equalsIgnoreCase("xml"))) {
            StringBuilder s = new StringBuilder();

            String pattern = "<" + name + "\\s+.*?>\\s*(.*?)\\s*</" + name + ">";
            Pattern r = Pattern.compile(pattern, Pattern.DOTALL);
            Matcher m = r.matcher(fileContent);

            if (!m.find() || name == null || name.isEmpty()) {
                System.out.println("Pattern not found or name is empty.");
                model.addAttribute("fileContent", fileContent);
            } else {
                do {
                    String itemsContent = m.group();
                    s.append(itemsContent).append("\n");
                } while (m.find());

                resultContent = s.toString();
                model.addAttribute("fileContent", resultContent);
            }
        }
        else if (type.equalsIgnoreCase("xlsx") || type.equalsIgnoreCase("xls")) {
            try (InputStream inputStream = file.getInputStream()) {
            	Workbook workbook = new XSSFWorkbook(inputStream);
            	Sheet sheet = workbook.getSheetAt(0);
            	StringBuilder contentBuilder = new StringBuilder();
            	int targetRow = -1;
            	for (Row row : sheet) {
            	    
            		for (Cell cell1 : row) {
            		    String cellValue;            		    
            		    if (cell1.getCellType() == CellType.STRING) {
            		        cellValue = cell1.getStringCellValue();
            		        if (cellValue.equalsIgnoreCase(name1)) {
                		        System.out.println(name1 + " found in row " + cell1.getColumnIndex());
                		        targetRow = cell1.getColumnIndex();
                		        break;
                		    }
            		    } else if (cell1.getCellType() == CellType.NUMERIC) {
            		        double numericValue = cell1.getNumericCellValue();
            		        cellValue = String.valueOf(numericValue);
            		    } else {
            		        continue;
            		    }
            		}
//            	System.out.println(targetRow);            		
            	    if (targetRow >= 0) {
            	        for (Row row1 : sheet) {
                            Cell cell = row1.getCell(targetRow);
                            if (cell != null) {
                                String cellValue = getCellValueAsString(cell);
                                contentBuilder.append(cellValue).append("\t");
                            }
                            contentBuilder.append("\n");
                        }
            	    } 
            	    else {
            	        for (Cell cell : row) {
            	            String cellValue = getCellValueAsString(cell);
            	            contentBuilder.append(cellValue).append("\t");
            	        }
            	    }
            	    contentBuilder.append("\n");
            	}
            	workbook.close();
                model.addAttribute("fileContent", contentBuilder.toString());
            }            
        }
        attributeRows.clear();
        return new ModelAndView("upload");
    }

 
    private String getCellValueAsString(Cell cell) {
        String cellValue = "";
        if (cell != null) {
            CellType cellType = cell.getCellType();
            switch (cellType) {
                case STRING:
                    cellValue = cell.getStringCellValue();
                    break;
                case NUMERIC:
                    cellValue = String.valueOf(cell.getNumericCellValue());
                    break;
            }
        }
        return cellValue;
    }
}
